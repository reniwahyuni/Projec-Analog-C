package reni;

import java.awt.EventQueue;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;



public class penjualanbarang {
	

	private JFrame frmN;
	private JTextField txtnama;
	private JTextField txtketerangan;
	private JTextField txtnamabarang;
	private JTextField txthargabarang;
	private JTextField txttotal;
	private JTextField txtdiskon;
	private JTextField txtuangbayar;
	private JTextField txtuangkembalian;
	private JTextField txtjumlahbeli;
	private JTextField txtsatuan;
 
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					penjualanbarang window = new penjualanbarang();
					window.frmN.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	
	ArrayList<penjualanbarang> penjualanbarang = new ArrayList<penjualanbarang>();
	
	
	public penjualanbarang() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmN = new JFrame();
		frmN.setTitle("n");
		frmN.setBounds(100, 100, 649, 579);
		frmN.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmN.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Penjualan Alat Tulis");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel.setBounds(201, 21, 181, 23);
		frmN.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nama Konsumen :");
		lblNewLabel_1.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(108, 63, 130, 14);
		frmN.getContentPane().add(lblNewLabel_1);
		
		txtnama = new JTextField();
		txtnama.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		txtnama.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		txtnama.setBounds(248, 60, 262, 20);
		frmN.getContentPane().add(txtnama);
		txtnama.setColumns(10);
		
		JLabel lblNewLabel_1_1 = new JLabel("Kode Konsumen :");
		lblNewLabel_1_1.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_1.setBounds(108, 95, 130, 14);
		frmN.getContentPane().add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Keterangan :");
		lblNewLabel_1_2.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_2.setBounds(108, 127, 130, 14);
		frmN.getContentPane().add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Kode Barang :");
		lblNewLabel_1_3.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_3.setBounds(49, 167, 106, 14);
		frmN.getContentPane().add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Nama Barang :");
		lblNewLabel_1_4.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_4.setBounds(41, 198, 106, 14);
		frmN.getContentPane().add(lblNewLabel_1_4);
		
		JLabel lblNewLabel_1_5 = new JLabel("Harga Barang :");
		lblNewLabel_1_5.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_5.setBounds(41, 229, 114, 14);
		frmN.getContentPane().add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Jumlah Beli :");
		lblNewLabel_1_6.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_6.setBounds(58, 261, 97, 14);
		frmN.getContentPane().add(lblNewLabel_1_6);
		
		JLabel lblNewLabel_1_8 = new JLabel("Diskon :");
		lblNewLabel_1_8.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_8.setBounds(92, 326, 63, 14);
		frmN.getContentPane().add(lblNewLabel_1_8);
		
		txtketerangan = new JTextField();
		txtketerangan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		txtketerangan.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		txtketerangan.setColumns(10);
		txtketerangan.setBounds(248, 124, 262, 20);
		frmN.getContentPane().add(txtketerangan);
		
		txtnamabarang = new JTextField();
		txtnamabarang.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		txtnamabarang.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		txtnamabarang.setColumns(10);
		txtnamabarang.setBounds(162, 195, 262, 20);
		frmN.getContentPane().add(txtnamabarang);
		
		txthargabarang = new JTextField();
		txthargabarang.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		txthargabarang.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		txthargabarang.setColumns(10);
		txthargabarang.setBounds(162, 226, 262, 20);
		frmN.getContentPane().add(txthargabarang);
		
		txttotal = new JTextField();
		txttotal.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		txttotal.setColumns(10);
		txttotal.setBounds(162, 352, 262, 20);
		frmN.getContentPane().add(txttotal);
		
		txtdiskon = new JTextField();
		txtdiskon.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		txtdiskon.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		txtdiskon.setColumns(10);
		txtdiskon.setBounds(162, 323, 262, 20);
		frmN.getContentPane().add(txtdiskon);
		
		txtuangbayar = new JTextField();
		txtuangbayar.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		txtuangbayar.setColumns(10);
		txtuangbayar.setBounds(162, 383, 262, 20);
		frmN.getContentPane().add(txtuangbayar);
		
		JLabel lblNewLabel_1_8_1 = new JLabel("Uang Bayar :");
		lblNewLabel_1_8_1.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_8_1.setBounds(58, 386, 97, 14);
		frmN.getContentPane().add(lblNewLabel_1_8_1);
		
		JLabel lblNewLabel_1_8_2 = new JLabel("Uang Kembalian :");
		lblNewLabel_1_8_2.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_8_2.setBounds(25, 417, 130, 14);
		frmN.getContentPane().add(lblNewLabel_1_8_2);
		
		txtuangkembalian = new JTextField();
		txtuangkembalian.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		txtuangkembalian.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		txtuangkembalian.setColumns(10);
		txtuangkembalian.setBounds(162, 414, 262, 20);
		frmN.getContentPane().add(txtuangkembalian);
		
		JButton btnsimpan = new JButton("Simpan");
		btnsimpan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		btnsimpan.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnsimpan.setBounds(434, 476, 81, 23);
		frmN.getContentPane().add(btnsimpan);
		
		JButton btntotal = new JButton("Proses Total Harga");
		btntotal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				double hargabarang, diskon, totalbayar;
				int jumlahbeli;
				
				hargabarang = Double.parseDouble(txthargabarang.getText());
				diskon = Double.parseDouble(txtdiskon.getText());
				jumlahbeli = Integer.parseInt(txtjumlahbeli.getText());
				
				totalbayar = (hargabarang * jumlahbeli) - diskon ;
				txttotal.setText(""+totalbayar);
			}
		});
		btntotal.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btntotal.setBounds(434, 352, 145, 23);
		frmN.getContentPane().add(btntotal);
		
		JButton btnproses = new JButton("Proses Diskon");
		btnproses.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				double hargabarang, diskon;
				int jumlahbeli;
				
				jumlahbeli = Integer.parseInt(txtjumlahbeli.getText());
				hargabarang = Double.parseDouble(txthargabarang.getText());
				
				if (jumlahbeli >= 10) {
					diskon = hargabarang * 0.1 ;
					
				}else
					{
						diskon = 0;
					}
				txtdiskon.setText(""+diskon);
		}
		});
		btnproses.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnproses.setBounds(434, 320, 145, 23);
		frmN.getContentPane().add(btnproses);
		
		JButton btnuangbayar = new JButton("Proses Uang Bayar");
		btnuangbayar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				double totalbayar, uangbayar, uangkembalian;
				
				totalbayar = Double.parseDouble(txttotal.getText());
				uangbayar = Double.parseDouble(txtuangbayar.getText());
				
				if (uangbayar > totalbayar) {
					uangkembalian = uangbayar - totalbayar;
					txtuangkembalian.setText(""+uangkembalian);
				}else
					{
						txtuangkembalian.setText("Uang Anda Kurang");
					}
			}
		});
		btnuangbayar.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnuangbayar.setBounds(434, 380, 145, 23);
		frmN.getContentPane().add(btnuangbayar);
		
		JComboBox cmbkodekonsumen = new JComboBox();
		cmbkodekonsumen.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String kodeks, keterangan;
				
				kodeks = String.valueOf(cmbkodekonsumen.getSelectedItem());
				if (kodeks.equals("PB001")) {
					keterangan = "Members";
				}else
					if (kodeks.equals("PB002")) {
						keterangan = "Konsumen Biasa";
				}else
					{
						keterangan = "Tidak Terdaftar";
					}
				txtketerangan.setText(""+keterangan);
				
					
			}
		});
		cmbkodekonsumen.setModel(new DefaultComboBoxModel(new String[] {"PB001", "PB002"}));
		cmbkodekonsumen.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		cmbkodekonsumen.setBounds(248, 91, 262, 22);
		frmN.getContentPane().add(cmbkodekonsumen);
		
		JComboBox cmbkodebarang = new JComboBox();
		cmbkodebarang.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String kdbarang,namabarang,satuan;
				double hargabarang;
				
				kdbarang = String.valueOf(cmbkodebarang.getSelectedItem());
				
				if (kdbarang.equals("BK001")) {
					namabarang= "Buku";
					hargabarang = 110000;
					satuan = "lusin";
				}else
					if (kdbarang.equals("PN002")) {
						namabarang= "Pena";
						hargabarang = 40000;
						satuan = "box";
				}else
					if (kdbarang.equals("PS003")) {
						namabarang= "Pensil";
						hargabarang = 30000;
						satuan = "pack";
				}else
					if (kdbarang.equals("TP004")) {
						namabarang= "Tipe X";
						hargabarang = 40000;
						satuan = "box";
				}else
					if (kdbarang.equals("PG005")) {
						namabarang= "Penghapus";
						hargabarang = 25000;
						satuan = "box";
				}else
					{kdbarang = "BN006";
					namabarang= "Binder";
					hargabarang = 30000;
					satuan = "pcs";
				}
				txtnamabarang.setText(""+namabarang);
				txthargabarang.setText(""+hargabarang);
				txtsatuan.setText(""+satuan);
						
						
					
			}
		});
		cmbkodebarang.setModel(new DefaultComboBoxModel(new String[] {"BK001", "PN002", "PS003", "TP004", "PG005", "BN006"}));
		cmbkodebarang.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		cmbkodebarang.setBounds(162, 163, 262, 22);
		frmN.getContentPane().add(cmbkodebarang);
		
		JLabel lblNewLabel_1_6_1 = new JLabel("Total Harga :");
		lblNewLabel_1_6_1.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_6_1.setBounds(58, 355, 97, 14);
		frmN.getContentPane().add(lblNewLabel_1_6_1);
		
		txtjumlahbeli = new JTextField();
		txtjumlahbeli.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		txtjumlahbeli.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		txtjumlahbeli.setColumns(10);
		txtjumlahbeli.setBounds(162, 257, 262, 20);
		frmN.getContentPane().add(txtjumlahbeli);
		
		JLabel lblNewLabel_1_6_2 = new JLabel("Satuan :");
		lblNewLabel_1_6_2.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		lblNewLabel_1_6_2.setBounds(92, 290, 63, 14);
		frmN.getContentPane().add(lblNewLabel_1_6_2);
		
		txtsatuan = new JTextField();
		txtsatuan.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		txtsatuan.setFont(new Font("Sitka Subheading", Font.PLAIN, 16));
		txtsatuan.setColumns(10);
		txtsatuan.setBounds(162, 288, 262, 20);
		frmN.getContentPane().add(txtsatuan);
		
		JButton btnexit = new JButton("X");
		btnexit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		btnexit.setBounds(578, 23, 47, 23);
		frmN.getContentPane().add(btnexit);
		
		JButton btnhapus = new JButton("Hapus");
		btnhapus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				txtnama.setText("");
				txtketerangan.setText("");
				txtnamabarang.setText("");
				txtsatuan.setText("");
				txtjumlahbeli.setText("");
				txtdiskon.setText("");
				txthargabarang.setText("");
				txttotal.setText("");
				txtuangbayar.setText("");
				txtuangkembalian.setText("");
				cmbkodebarang.setSelectedItem(null);
				cmbkodekonsumen.setSelectedItem(null);
				txtnama.requestFocus();
			}
		});
		btnhapus.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		btnhapus.setBounds(66, 476, 81, 23);
		frmN.getContentPane().add(btnhapus);
	}
}
